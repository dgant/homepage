Thanks for trying out Midgets With Attitude.

NOTE:
---
Due to an unfortunate loss of software, this is an old test version of Midgets With Attitude, and regrettably contains sequenced versions of copyrighted music that is not mine. My apologies to those whose work is here without permission:

Darude
Blink 182
Stone Temple Pilots
Dave Kelly
Sega
Capcom
Several anonymous artists

The most recent version of the game contains a wholly original soundtrack, replacing the unlicensed material, but due to the loss of my copy of Multimedia Fusion, this version is unabailable. For the actual soundtrack to the game, please contact me.
---

Installation Instructions:
---
Simply copy all the files (mwa2.exe, CNCS32.dll, CNCS232.dll) to a directory of your choice, and run mwa2.exe. There is no setup process.
---