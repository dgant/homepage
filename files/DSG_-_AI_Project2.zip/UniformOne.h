#ifndef UNIFORM_ONE_H
#define UNIFORM_ONE_H

// UniformOne()
//
// Just returns 1, for trivial calculations.

int UniformOne( PuzzleBoard&, Coord )
{
	return 1;
}

#endif

