#ifndef SUMMED_MANHATTAN_DISTANCE_H
#define SUMMED_MANHATTAN_DISTANCE_H

// SummedManhattanDistance
//
// Returns the sum of the total orthogonal distance from each tile to its goal location.
// Because the puzzle can't be solved in fewer moves, this is an admissible heuristic.

int SummedManhattanDistance( PuzzleBoard& iBoard, Coord iMove )
{
	int cost(0);

	iBoard.ExecuteMove( iMove );

	for( int i = 0; i < iBoard.GetArea(); ++i )
	{
		cost += abs(iBoard.At(i%iBoard.GetWidth(), i/iBoard.GetWidth())%iBoard.GetWidth() - i%iBoard.GetWidth());
		cost += abs(iBoard.At(i%iBoard.GetWidth(), i/iBoard.GetWidth())/iBoard.GetWidth() - i/iBoard.GetWidth());
	}

	iBoard.UndoMove( iMove );

	return cost;
}

#endif