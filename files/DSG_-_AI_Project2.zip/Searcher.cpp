#include "Searcher.h"

Searcher::Searcher( int(* iCostCalculator      )( PuzzleBoard&, Coord ),
                    int(* iHeuristicCalculator )( PuzzleBoard&, Coord ))
	: mCostCalculator(iCostCalculator)
	, mHeuristicCalculator(iHeuristicCalculator)
	, mNumberOfOpenNodes(0) {}

Searcher::~Searcher()
{
	/*================================================*/ 
	/* Destructor                                     */ 
	/*                                                */ 
	/* Searcher is responsible for nodes stored in,   */ 
	/* mOpen and mClosed, requiring explicit deletion.*/ 
	/*================================================*/ 

	for( NodeHashMultimap::iterator i = mOpen.begin(); i != mOpen.end(); ++i )
	{
		for( NodeVector::iterator j = i->begin(); j != i->end(); ++j ) delete *j;
	}
	for( NodeVector::iterator i = mClosed.begin(); i != mClosed.end(); ++i ) delete *i;
}

void Searcher::CloseNode( NodeHashMultimap::iterator iVector, NodeVector::iterator iNode )
{
	/*=================================*/ 
	/* CloseNode()                     */ 
	/*                                 */ 
	/* Move a node to the closed list. */ 
	/*=================================*/ 
	
	mClosed.push_back( *iNode );
	iVector->erase( iNode );

	--mNumberOfOpenNodes;
}

SearchResults Searcher::Solve( PuzzleBoard iBoard )
{
	/*===================================*/ 
	/* Solve()                           */ 
	/*                                   */ 
	/* Default algorithm for solving a   */ 
	/* search problem, given a method    */ 
	/* for ordering newly expanded nodes */ 
	/*===================================*/ 

	Node* last_visited = NULL;

	NodeHashMultimap::iterator  current_key;
	NodeVector::iterator        current_node;

	AddFirstNode( new Node(Coord::NoMove(), NULL,
		(mCostCalculator)(iBoard,Coord::NoMove()),
		(mHeuristicCalculator)(iBoard,Coord::NoMove()) ));
	
	for(;;)
	{
		// - Visit first node on open list
		// - Check if it's a goal node, and if it is, return results.
		// - Expand node and add children to open list
		// - Add current node to closed list
		// - If no open nodes remain, return failure.
		
		for( NodeHashMultimap::iterator i = mOpen.begin();; ++i )
		{
			if( !i->empty() )
			{
				current_key = i;
				current_node = i->begin();
				break;
			}
		}

		(*current_node)->VisitFrom( last_visited, iBoard );

		if( iBoard.PuzzleSolved() )
		{
			SearchResults results(true);

			Node* top = *current_node;

			while( top != NULL )
			{
				results.mMoves.push_front( top->GetMove() );
				top = top->GetParent();
			}

			return results;
		}		

		last_visited = *current_node;
		CloseNode( current_key, current_node );

		last_visited->Expand( iBoard, mCostCalculator, mHeuristicCalculator );
		AddOpenNodes( last_visited );		
	}

	return SearchResults( false );
}

void Searcher::PrintSearchResults() const
{
	std::cout << "Search results:" << std::endl;
	std::cout << "\tNodes searched: " << mNumberOfOpenNodes + static_cast<int>(mClosed.size()) << std::endl;
	std::cout << "\tNodes on open list: " << mNumberOfOpenNodes << std::endl;
	std::cout << "\tNodes on closed list: " << static_cast<int>(mClosed.size()) << std::endl;
}

void Searcher::AddFirstNode( Node* iNode )
{
	/*============================================*/ 
	/* AddFirstNode() (Virtual)                   */ 
	/*                                            */ 
	/* Creates first node of search tree.         */ 
	/* Heuristic- or cost-based searches can      */ 
	/* override AddFirstNode() to place the first */ 
	/* node in a location of their choosing       */ 
	/*============================================*/ 

	mOpen.resize(1);
	mOpen[0].push_back( iNode );

	++mNumberOfOpenNodes;
}