#ifndef SUMMED_SQUARED_MANHATTAN_DISTANCE_H
#define SUMMED_SQUARED_MANHATTAN_DISTANCE_H

// SummedSquaredManhattanDistance
//
// Returns the sum of the squares of the total orthogonal distance from each tile to its goal location.
// Because the puzzle can't be solved in fewer moves, this is an admissible heuristic.

int SummedSquaredManhattanDistance( PuzzleBoard& iBoard, Coord iMove )
{
	int cost(0);

	iBoard.ExecuteMove( iMove );

	for( int i = 0; i < iBoard.GetArea(); ++i )
	{
		cost +=	( abs(iBoard.At(i%iBoard.GetWidth(), i/iBoard.GetWidth())%iBoard.GetWidth() - i%iBoard.GetWidth()) + abs(iBoard.At(i%iBoard.GetWidth(), i/iBoard.GetWidth())/iBoard.GetWidth() - i/iBoard.GetWidth()))^2;
	}

	iBoard.UndoMove( iMove );

	return cost;
}

#endif