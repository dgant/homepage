#ifndef COORD_H
#define COORD_H

#include <list>

// Struct: Coord
//
// 2D integer coordinate
// Used to represent board locations and movement across the board

struct Coord
{
	typedef std::list<Coord> MoveList;

	int x;
	int y;

	Coord( int iX, int iY ): x(iX), y(iY) {}
	Coord():                 x(0),  y(0)  {}

	static Coord Up()     { return Coord(0,-1); }
	static Coord Down()   { return Coord(0, 1); }
	static Coord Left()   { return Coord(-1,0); }
	static Coord Right()  { return Coord(1, 0); }
	static Coord NoMove() { return Coord(0, 0); }

	void Set( int iX, int iY ){ x = iX; y = iY; }
};

#endif