#include "Node.h"

Node::Node( Coord iMove, Node* iParent, int iCost, int iHeuristic )
	: mMove(iMove)
	, mParent(iParent)
	, mCost(iCost)
	, mHeuristic(iHeuristic)
	, mChildren() {}

int Node::GetCost()                          const { return mCost;      }
int Node::GetHeuristic()                     const { return mHeuristic; }
Coord Node::GetMove()                        const { return mMove;      }
Node* Node::GetParent()                      const { return mParent;    }
const std::list<Node*>& Node::GetChildren()  const { return mChildren;  }

void Node::VisitFrom( const Node* const iCurrentNode, PuzzleBoard& iBoard ) const
{
	// VisitFrom()
	//
	// Visit this node's board position from a board at a given node

	/*=============================================*/ 
	/* Recurse back through the tree either        */ 
	/* to the initial position or                  */ 
	/* to the current node, whichever comes first. */ 
	/*                                             */ 
	/* Then, execute all the moves until the       */ 
	/* current position is reached.                */ 
	/*=============================================*/ 

	if( mParent != NULL )
	{
		if( mParent != iCurrentNode ) mParent->VisitFrom( iCurrentNode, iBoard );
	}
	else if( iCurrentNode != NULL )
	{
		iCurrentNode->RetreatTo( this, iBoard );
	}

	iBoard.ExecuteMove( mMove );
}

void Node::RetreatTo( const Node* const iTargetNode, PuzzleBoard& iBoard ) const
{
	iBoard.UndoMove( mMove );

	if( mParent != NULL && mParent != iTargetNode ) mParent->RetreatTo( iTargetNode, iBoard );
}

void Node::Expand( PuzzleBoard& iBoard,
			int(* iCostCalculator      )( PuzzleBoard&, Coord ),
			int(* iHeuristicCalculator ) (PuzzleBoard&, Coord ) )
{
	Coord::MoveList moves;

	iBoard.GetLegalMoves( moves );

	for( Coord::MoveList::iterator i = moves.begin(); i != moves.end(); ++i )
	{

		// Unless move is the reverse of this node's move, add it to legal moves.
		//
		// !note! Is this restriction appropriate? Practically, it's an improvement,
		// but it's kind of misplaced in the Node's logic.

		if( !(i->x == -mMove.x && i->y == -mMove.y)  ) 
		{
			mChildren.push_back( new Node( *i, this,
				mCost + (iCostCalculator)(iBoard,*i),
				(iHeuristicCalculator(iBoard,*i) )));
		}
	}
}
