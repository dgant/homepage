#ifndef BFS_SEARCHER_H
#define BFS_SEARCHER_H

#include "Searcher.h"

class BFS_Searcher: public Searcher
{
	public:
		BFS_Searcher( int(* iCostCalculator      )( PuzzleBoard&, Coord ),
		              int(* iHeuristicCalculator )( PuzzleBoard&, Coord ))
			: Searcher(iCostCalculator, iHeuristicCalculator) {}

		virtual void AddOpenNodes( Node* iSource )
		{
            const std::list<Node*>& new_nodes( iSource->GetChildren() );

			for( std::list<Node*>::const_iterator i = new_nodes.begin(); i != new_nodes.end(); ++i )
			{
				// For a breadth-first search, newly expanded nodes are visited last

				mOpen[0].push_back( *i );

				++mNumberOfOpenNodes;
			}
		}
};

#endif