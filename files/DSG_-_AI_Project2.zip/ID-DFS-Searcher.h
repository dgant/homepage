#ifndef ID_DFS_SEARCHER_H
#define ID_DFS_SEARCHER_H

#include "Searcher.h"

class ID_DFS_Searcher: public Searcher
{
	private:
		int mDepth;

	public:
		ID_DFS_Searcher( int(* iCostCalculator      )( PuzzleBoard&, Coord ),
		                 int(* iHeuristicCalculator )( PuzzleBoard&, Coord ))
			: Searcher(iCostCalculator, iHeuristicCalculator)
			, mDepth(1) {}

		virtual void AddOpenNodes( Node* iSource )
		{
            const std::list<Node*>& new_nodes( iSource->GetChildren() );

			for( std::list<Node*>::const_iterator i = new_nodes.begin(); i != new_nodes.end(); ++i )
			{
				// For a depth-first search, newly expanded nodes are visited first

				mOpen[0].insert( mOpen[0].begin(), *i );

				++mNumberOfOpenNodes;
			}
		}

		// We must reimplement Solve to handle the iterative deepening.

		virtual SearchResults Solve( PuzzleBoard iBoard )
		{
			PuzzleBoard board_copy(iBoard);

			Node* last_visited = NULL;

			NodeHashMultimap::iterator  current_key;
			NodeVector::iterator        current_node;

			AddFirstNode( new Node(Coord::NoMove(), NULL,
				(mCostCalculator)(iBoard,Coord::NoMove()),
				(mHeuristicCalculator)(iBoard,Coord::NoMove()) ));
			
			for(;;)
			{
				// - Visit first node on open list
				// - Check if it's a goal node, and if it is, return results.
				// - Expand node and add children to open list
				// - Add current node to closed list
				// - If no open nodes remain, return failure.
				
				for( NodeHashMultimap::iterator i = mOpen.begin();; ++i )
				{
					if( !i->empty() )
					{
						current_key = i;
						current_node = i->begin();
						break;
					}
				}

				(*current_node)->VisitFrom( last_visited, iBoard );

				if( iBoard.PuzzleSolved() )
				{
					SearchResults results(true);

					Node* top = *current_node;

					while( top != NULL )
					{
						results.mMoves.push_front( top->GetMove() );
						top = top->GetParent();
					}

					return results;
				}		

				last_visited = *current_node;
				CloseNode( current_key, current_node );

				if( last_visited->GetCost() < mDepth )
				{
					last_visited->Expand( iBoard, mCostCalculator, mHeuristicCalculator );
					AddOpenNodes( last_visited );
				}

				// Iteratively deepen (Or in this case, recursively deepen)
				// GetNumberOfOpenNodes() is slow...
				//
				if( mNumberOfOpenNodes == 0 )
				{
					++mDepth;
					for( NodeVector::iterator i = mClosed.begin(); i != mClosed.end(); ++i ) delete *i;
					mOpen.clear();
					mClosed.clear();
					return Solve( board_copy );					
				}
			}

			return SearchResults( false );
		}
};

#endif