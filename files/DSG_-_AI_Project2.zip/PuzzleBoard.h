#ifndef PUZZLEBOARD_H
#define PUZZLEBOARD_H

#include "Coord.h"
#include <vector>

// Class: PuzzleBoard
//
// Stores an N-puzzle and provides tools for accessing and manipulating it

class PuzzleBoard
{
	private:
		/* Width of board */ 
		const int cmWidth;
		const int cmArea;

		/* Puzzle itself */ 
		std::vector< std::vector<int> > mBoard;

		/* Location of puzzle hole */ 
		Coord mHole;                  

	public:
		PuzzleBoard( int iWidth );

		/* Const accessors */ 
		int GetWidth() const;
		int GetArea() const;

		int At( const Coord& iCoord ) const;
		int At( int iX, int iY ) const;

		Coord GetHoleLocation() const;

		/* Redundant tools */ 
		bool PuzzleSolved() const;
		void PrintBoard() const;
		void GetLegalMoves( Coord::MoveList& iMoves ) const;

		/* Interface for modifying board */ 
		void ExecuteMove( const Coord& iMove );
		void UndoMove( const Coord& iMove );

		void Randomize( int iMoves );

	private:
		/* Defines the value of empty tile in sliding puzzle */ 
		int HoleValue() const;

		/* Tile modifiers */ 
		void Set( const Coord& iCoord, int iValue );
		void Set( int iX, int iY, int iValue );
};

#endif