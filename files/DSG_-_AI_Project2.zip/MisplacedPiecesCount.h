#ifndef MISPLACED_PIECES_COUNT_H
#define MISPLACED_PIECES_COUNT_H

// MisplacedPiecesCount
//
// Returns the number of misplaced pieces

int MisplacedPiecesCount( PuzzleBoard& iBoard, Coord iMove )
{
	int cost(0);

	iBoard.ExecuteMove( iMove );

	for( int i = 0; i < iBoard.GetWidth(); ++i )
	{
		for( int j = 0; j < iBoard.GetWidth(); ++j )
		{
			if( iBoard.At(i,j) != i + j*iBoard.GetWidth() ) cost += 1;
		}

	}		

	iBoard.UndoMove( iMove );

	return cost;
}

#endif