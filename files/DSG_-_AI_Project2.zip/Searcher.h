#ifndef SEARCHER_H
#define SEARCHER_H

#include "Coord.h"
#include "PuzzleBoard.h"
#include "Node.h"
#include <iostream>
#include <vector>

// Struct: SearchResults

struct SearchResults
{
	bool mSuccess;
	Coord::MoveList mMoves;

	SearchResults( bool iSuccess, Coord::MoveList iMoves=Coord::MoveList() ): mSuccess(iSuccess), mMoves(iMoves) {}
};

// Class: Searcher
//
// Base class for all search implementations.
//
// Stores open nodes in a multimap in which the chosen
// heuristic (if any) is the key value. For searches
// that don't use heuristics, all nodes are placed in
// index 0.
//
// Implemented as vector of vectors to avoid 
// ugliness of STL's multimap implementation.

class Searcher
{
	protected:
		typedef std::vector<Node*>      NodeVector;
		typedef std::vector<NodeVector> NodeHashMultimap;
		
		NodeHashMultimap  mOpen;
		NodeVector        mClosed;

		int mNumberOfOpenNodes;

		int(* mCostCalculator      )( PuzzleBoard&, Coord );
		int(* mHeuristicCalculator )( PuzzleBoard&, Coord );

	public:
		Searcher( int(* iCostCalculator      )( PuzzleBoard&, Coord ),
		          int(* iHeuristicCalculator )( PuzzleBoard&, Coord ));

		virtual ~Searcher();
		virtual SearchResults Solve( PuzzleBoard iBoard );

		void PrintSearchResults() const;

	protected:
		void CloseNode( NodeHashMultimap::iterator iKey, NodeVector::iterator iNode );

		virtual void AddFirstNode( Node* iNode   );
		virtual void AddOpenNodes( Node* iSource ) = 0;
};

#endif