#ifndef NODE_H
#define NODE_H

#include "PuzzleBoard.h"

// Class: Node
//
// Stores 
//
// This implementation stores the move that differentiates
// the current state from the previous move, rather than
// storing the state itself. This conserves memory at the
// cost of having to recalculate the board state every
// time a node is expanded. Overall, this greatly speeds
// up most searches (which hit memory limits rather quickly)
// but slows down depth-first searches.

class Node
{
	private:
		// Move that converts the parent's state into this node's state
		Coord mMove;

		// If proscribed, these store the total cost of visiting this node,
		// and the estimated cost of reaching the goal state.
		int mCost;
		int mHeuristic;

		// Store pointers to this node's parent and children.
		// Note that a Searcher is responsible for the storage and deletion
		// of nodes, so Node can use the default destructor.

		Node* mParent;
		std::list<Node*> mChildren;

	public:
		Node( Coord iMove, Node* iParent, int iCost, int iHeuristic );

		/* Const accessors */ 
		Coord GetMove() const;

		int GetCost() const;
		int GetHeuristic() const;

		Node* GetParent() const;
		const std::list<Node*>& GetChildren() const;

		/* Transform board from a previous state to this node's state */ 
		void VisitFrom( const Node* const iCurrentNode, PuzzleBoard& iBoard ) const;
		
		/* Create this node's children */ 
		void Expand( PuzzleBoard& iBoard,
			int(* iCostCalculator      )( PuzzleBoard&, Coord ),
			int(* iHeuristicCalculator )( PuzzleBoard&, Coord ) );

	private:
		/* Used by VisitFrom() */ 
		void RetreatTo( const Node* const iTargetNode,  PuzzleBoard& iBoard ) const;
};

#endif