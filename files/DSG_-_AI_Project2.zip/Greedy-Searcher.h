#ifndef GREEDY_SEARCHER_H
#define GREEDY_SEARCHER_H

#include "Searcher.h"

class Greedy_Searcher: public Searcher
{
	public:
		Greedy_Searcher( int(* iCostCalculator      )( PuzzleBoard&, Coord ),
		                 int(* iHeuristicCalculator )( PuzzleBoard&, Coord ))
			: Searcher(iCostCalculator, iHeuristicCalculator) {}
		virtual void AddOpenNodes( Node* iSource )
		{
			const std::list<Node*>& new_nodes( iSource->GetChildren() );

			for( std::list<Node*>::const_iterator i = new_nodes.begin(); i != new_nodes.end(); ++i )
			{
				// For A* search, insert node in order of cost+heuristic

				while( (*i)->GetHeuristic() >= static_cast<int>(mOpen.size()) )
				{
					mOpen.resize( mOpen.size() * 2 );

					++mNumberOfOpenNodes;
				}

				mOpen[(*i)->GetHeuristic()].push_back( *i );
			}
		}

		virtual void AddFirstNode( Node* iNode )
		{
			mOpen.resize(iNode->GetHeuristic()+1);
			mOpen[iNode->GetHeuristic()].push_back( iNode );

			++mNumberOfOpenNodes;
		}
};

#endif