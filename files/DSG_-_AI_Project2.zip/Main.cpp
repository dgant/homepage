#include <cstdlib>
#include <ctime>
#include <string>
#include <iostream>

#include "PuzzleBoard.h"
#include "BFS-Searcher.h"
#include "DFS-Searcher.h"
#include "A-Searcher.h"
#include "Greedy-Searcher.h"
#include "UCS-Searcher.h"
#include "ID-DFS-Searcher.h"

#include "SummedManhattanDistance.h"
#include "MisplacedPiecesCount.h"
#include "UniformOne.h"

void UnitTestBoard();
void MultiSearch( int iBoardSize, int iComplexity );
void Search( Searcher* iSearcher, PuzzleBoard& iBoard );

using std::cout;
using std::endl;

int main( int argc , char* argv[] )
{
	srand( static_cast<unsigned int>(time(NULL)) );

	/*=================================*/ 
	/* Print intro message, then pause */ 
	/*=================================*/ 

	cout << "Assignment #2\nBy Dan Gant (dsg2110@columbia.edu)\nFor COMS W4701 Artificial Intelligence\nProf. Stolfo" << endl << endl; 
	cout << "This program will create three random 15-Puzzles, shuffled " << endl;
	cout << "by 15, 25, and 35 random moves, respectively. The actual   " << endl;
	cout << "solutions may require substantially fewer moves to solve.  " << endl;
	cout << endl;
	cout << "To solve these puzzles, the program will use ten methods:  " << endl;
	cout << endl;
	cout << "\t- A*, using as a heuristic the sum of the orthogonal     " << endl;
	cout << "\t  displacements of every tile                            " << endl;
	cout << "\t- Greedy search with the same heuristic                  " << endl;
	cout << "\t- A*, using as a heuristic the number of displaced tiles " << endl;
	cout << "\t- Greedy search with the same heuristic                  " << endl;
	cout << "\t- Uniform-cost search                                    " << endl;
	cout << "\t- Iterative deepening depth-first search                 " << endl;
	cout << "\t- Breadth-first search                                   " << endl;
	cout << "\t- Depth-first search up to depths of N/2, N/3, and N/4,  " << endl;
	cout << "\t  where N is the number of random moves made on the board" << endl;
	cout << endl;
	
	std::string garbage;
	cout << "Press [ENTER] to begin." << endl;
	getline(std::cin, garbage);

	/*=======================================*/ 
	/* Generate and search random 4x4 boards */ 
	/*=======================================*/ 

	MultiSearch(4, 15);
	MultiSearch(4, 25);
	MultiSearch(4, 35);

	cout << "Press [ENTER] to exit." << endl;
	getline(std::cin, garbage);

	return 0;
}

void MultiSearch( int iBoardSize, int iComplexity )
{
	// MultiSearch()
	//
	// Perform the full battery of search tests on a randomized board.

	cout << "####################################################" << endl;
	cout << "# Solving following board, randomized to " << iComplexity << " moves: " << (iComplexity<10?" ":"") << "#" << endl;
	cout << "####################################################" << endl;

	PuzzleBoard board(iBoardSize);
	board.Randomize(iComplexity);
	board.PrintBoard();

	cout << endl << endl;

	cout << "=====================================================================" << endl;
	cout << "Attempting to solve by A* using Summed Manhattan Distance:" << endl;
	Search( new A_Searcher(&UniformOne, &SummedManhattanDistance), board );
	cout << "A* complete." << endl << endl << endl;

	cout << "=====================================================================" << endl;
	cout << "Attempting to solve by Greedy search using Summed Manhattan Distance:" << endl;
	Search( new A_Searcher(&UniformOne, &SummedManhattanDistance), board );
	cout << "Greedy search complete." << endl << endl << endl;

	cout << "=====================================================================" << endl;
	cout << "Attempting to solve by A* using Misplaced Pieces Count:" << endl;
	Search( new A_Searcher(&UniformOne, &MisplacedPiecesCount), board );
	cout << "A* complete." << endl << endl << endl;

	cout << "=====================================================================" << endl;
	cout << "Attempting to solve by Greedy search using Misplaced Pieces Count:" << endl;
	Search( new A_Searcher(&UniformOne, &MisplacedPiecesCount), board );
	cout << "Greedy search complete." << endl << endl << endl;

	cout << "=====================================================================" << endl;
	cout << "Attempting to solve by iterative deepening depth-first search:" << endl;
	Search( new ID_DFS_Searcher(&UniformOne, &UniformOne), board );
	cout << "ID-DFS complete." << endl << endl << endl;

	cout << "=====================================================================" << endl;
	cout << "Attempting to solve by uniform-cost search:" << endl;
	Search( new UCS_Searcher(&UniformOne, &UniformOne), board );
	cout << "UCS complete." << endl << endl << endl;

	cout << "=====================================================================" << endl;
	cout << "Attempting to solve by breadth-first search:" << endl;
	Search( new BFS_Searcher(&UniformOne, &UniformOne), board );
	cout << "BFS complete." << endl << endl << endl;

	cout << "=====================================================================" << endl;
	cout << "Attempting to solve by depth-first search" << endl;
	cout << "limited to a depth of " << iComplexity/2 << " moves:" << endl;
	Search( new DFS_Searcher(&UniformOne, &UniformOne, iComplexity/2), board );
	cout << "DFS complete." << endl << endl << endl;

	cout << "=====================================================================" << endl;
	cout << "Attempting to solve by depth-first search" << endl;
	cout << "limited to a depth of " << iComplexity/3 << " moves:" << endl;
	Search( new DFS_Searcher(&UniformOne, &UniformOne, iComplexity/3), board );
	cout << "DFS complete." << endl << endl << endl;

	cout << "=====================================================================" << endl;
	cout << "Attempting to solve by depth-first search" << endl;
	cout << "limited to a depth of " << iComplexity/4 << " moves:" << endl;
	Search( new DFS_Searcher(&UniformOne, &UniformOne, iComplexity/4), board );
	cout << "DFS complete." << endl << endl << endl;
}

void Search( Searcher* iSearcher, PuzzleBoard& iBoard )
{
	// Search()
	//
	// Perform a search and print its results

	SearchResults results( iSearcher->Solve( iBoard ) );
	cout << "Search completed. " << (results.mSuccess?"Solution found:":"No solution found") << endl;

	if( results.mSuccess )
	{
		// Print moves, at five per line.
		// Skip first move, since it'll always be (0, 0)

		int moves_printed = 0;

		for( Coord::MoveList::const_iterator i = ++results.mMoves.begin(); i != results.mMoves.end(); ++i )
		{
			cout << "(" << i->x << ", " << (i->x>=0?" ":"") << (i->y>=0?" ":"") << i->y << ")  ";

			++moves_printed;
			if( moves_printed % 5 == 0 ) cout << endl;
		}

		cout << endl;
	}

	iSearcher->PrintSearchResults();

	delete iSearcher;
}