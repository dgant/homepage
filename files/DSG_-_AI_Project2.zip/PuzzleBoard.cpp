#include "PuzzleBoard.h"

#include <cmath>
#include <iostream>

PuzzleBoard::PuzzleBoard( int iWidth )
	: cmWidth(iWidth)
	, cmArea(cmWidth*cmWidth)
{
	/*===========================*/ 
	/* Default constructor       */ 
	/*                           */ 
	/* Creates a new blank board */ 
	/*===========================*/ 
	
	/* Size board */ 
	mBoard.resize(iWidth);
	for( int i = 0; i < iWidth; ++i )
	{
		mBoard.at(i).resize(iWidth);
	}

	/* Set up tiles */ 
	for( int i = 0; i < cmWidth; ++i )
	{
		for( int j = 0; j < cmWidth; ++j )
		{
            Set( i,j, 1 + i + cmWidth * j );
		}
	}

	/* Add hole in bottom right corner */ 
	mHole = Coord( cmWidth-1, cmWidth-1 );
	Set( mHole, HoleValue() );

}


int PuzzleBoard::HoleValue() const
{
	return cmArea;
}


int PuzzleBoard::GetWidth() const
{
	return cmWidth;
}


int PuzzleBoard::GetArea() const
{
	return cmArea;
}


bool PuzzleBoard::PuzzleSolved() const
{
	/*===============================*/ 
	/* PuzzleSolved()                */                             
	/*                               */ 
	/* Check whether the puzzle is   */ 
	/* currently in its solved state */ 
	/*===============================*/ 

	// Check most likely suspect first
	if( mHole.x != mHole.y || mHole.x != cmWidth - 1 ) return false;

	for( int i = 0; i < cmArea - 1; ++i )
	{
		if( mBoard[i%cmWidth][i/cmWidth] != i + 1 ) return false;
	}

	return true;
}


int PuzzleBoard::At( const Coord& iCoord ) const
{
	/*===========================================*/ 
	/* At()                                      */ 
	/*                                           */ 
	/* Access value of tile at given coordinates */ 
	/*===========================================*/ 

	return mBoard.at(iCoord.x).at(iCoord.y);
}


int PuzzleBoard::At( int iX, int iY ) const
{
	/*===========================================*/ 
	/* At()                                      */ 
	/*                                           */ 
	/* Access value of tile at given X and Y     */ 
	/*===========================================*/ 

	return mBoard.at(iX).at(iY);
}


Coord PuzzleBoard::GetHoleLocation() const
{
	/*===========================================*/ 
	/* GetHoleLocation()                         */ 
	/*                                           */ 
	/* Get location of empty tile                */ 
	/*===========================================*/ 

	return mHole;
}


void PuzzleBoard::PrintBoard() const 
{
	/*=============================*/ 
	/* PrintBoard()                */ 
	/*                             */ 
	/* Print board to standard out */ 
	/*=============================*/ 

	std:: cout << std::endl;

	for( int j = 0; j < cmWidth; ++j )
	{
		for( int i = 0; i < cmWidth; ++i )
		{
			if( At( i, j ) == HoleValue() )
			{
				std::cout << "_  ";
			}
			else
			{
				std::cout << At( i, j ) << " ";

				if( At( i, j ) < 10 ) std::cout << " "; // Add extra space for single-digit numbers
			}
		}

		std::cout << std::endl;
	}
}

void PuzzleBoard::Randomize( int iMoveNum )
{
	/*=======================================*/ 
	/* Randomize()                           */ 
	/*                                       */ 
	/* Randomize the board position by       */ 
	/* making iMoves random moves.           */ 
	/*=======================================*/ 
	
	Coord::MoveList::const_iterator move;
	Coord::MoveList legal_moves;

	for( int i = 0; i < iMoveNum; ++i )
	{
		GetLegalMoves( legal_moves );

		// This effectively runs in constant time because the MoveList's size is capped at four.

		move = legal_moves.begin();

		for( size_t j = rand() % legal_moves.size(); j > 0; --j ) ++move;

		ExecuteMove( *move );
	}
}


void PuzzleBoard::ExecuteMove( const Coord& iMove )
{
	/*================================================*/ 
	/* ExecuteMove()                                  */ 
	/*                                                */ 
	/* Execute the given move.                        */ 
	/* The hole will move in the direction indicated. */ 
	/*================================================*/ 

	Set( mHole, At( mHole.x + iMove.x, mHole.y + iMove.y ) );

	mHole.Set( mHole.x + iMove.x, mHole.y + iMove.y);

	Set( mHole, HoleValue() );
}

void PuzzleBoard::UndoMove( const Coord& iMove )
{
	/*=====================================================*/  
	/* UndoMove()                                          */ 
	/*                                                     */ 
	/* Undo the given move.                                */ 
	/* The hole will move against the direction indicated. */ 
	/*=====================================================*/ 

	Set( mHole, At( mHole.x - iMove.x, mHole.y - iMove.y ) );

	mHole.Set( mHole.x - iMove.x, mHole.y - iMove.y);

	Set( mHole, HoleValue() );
}


inline void PuzzleBoard::Set( const Coord& iCoord, int iValue )
{
	/*=============================*/ 
	/* Set()                       */ 
	/*                             */ 
	/* Change the value of a tile. */ 
	/*=============================*/ 

	mBoard.at(iCoord.x).at(iCoord.y) = iValue;
}


inline void PuzzleBoard::Set( int iX, int iY, int iValue )
{
	/*=============================*/ 
	/* Set()                       */ 
	/*                             */ 
	/* Change the value of a tile. */ 
	/*=============================*/ 

	mBoard.at(iX).at(iY) = iValue;
}

void PuzzleBoard::GetLegalMoves( Coord::MoveList& iMoves ) const
{
	/*===================================================*/ 
	/* GetLegalMoves()                                   */ 
	/*                                                   */ 
	/* Fill iMoves with all legal moves on current board */ 
	/*===================================================*/ 

	iMoves.clear();

	// Some searches, like depth-first search, will benefit from having
	// the order of the list of legal moves randomized.
	//
	// Though comically inelegant, this is probably the computationally cheapest
	// way of randomizing the order in which the legal moves are added.

	switch( rand() % 24 ) //!magic! There are 4*3*2*1 = 24 orderings of the four directions
	{
		/* Left first */ 
		case 0:
			if( mHole.x > 0 )            iMoves.push_back( Coord::Left()  );
			if( mHole.y > 0 )            iMoves.push_back( Coord::Up()    );
			if( mHole.x < cmWidth - 1 )  iMoves.push_back( Coord::Right() );
			if( mHole.y < cmWidth - 1 )  iMoves.push_back( Coord::Down()  );
			break;

		case 1:
			if( mHole.x > 0 )            iMoves.push_back( Coord::Left()  );
			if( mHole.y > 0 )            iMoves.push_back( Coord::Up()    );
			if( mHole.y < cmWidth - 1 )  iMoves.push_back( Coord::Down()  );
			if( mHole.x < cmWidth - 1 )  iMoves.push_back( Coord::Right() );
			break;

		case 2:
			if( mHole.x > 0 )            iMoves.push_back( Coord::Left()  );
			if( mHole.x < cmWidth - 1 )  iMoves.push_back( Coord::Right() );
			if( mHole.y < cmWidth - 1 )  iMoves.push_back( Coord::Down()  );
			if( mHole.y > 0 )            iMoves.push_back( Coord::Up()    );
			break;

		case 3:
			if( mHole.x > 0 )            iMoves.push_back( Coord::Left()  );
			if( mHole.x < cmWidth - 1 )  iMoves.push_back( Coord::Right() );
			if( mHole.y > 0 )            iMoves.push_back( Coord::Up()    );
			if( mHole.y < cmWidth - 1 )  iMoves.push_back( Coord::Down()  );
			break;

		case 4:
			if( mHole.x > 0 )            iMoves.push_back( Coord::Left()  );
			if( mHole.y < cmWidth - 1 )  iMoves.push_back( Coord::Down()  );
			if( mHole.x < cmWidth - 1 )  iMoves.push_back( Coord::Right() );
			if( mHole.y > 0 )            iMoves.push_back( Coord::Up()    );
			break;

		case 5:
			if( mHole.x > 0 )            iMoves.push_back( Coord::Left()  );
			if( mHole.y < cmWidth - 1 )  iMoves.push_back( Coord::Down()  );
			if( mHole.y > 0 )            iMoves.push_back( Coord::Up()    );
			if( mHole.x < cmWidth - 1 )  iMoves.push_back( Coord::Right() );			
			break;

		/* Right first */ 
		case 6:
			if( mHole.x < cmWidth - 1 )  iMoves.push_back( Coord::Right() );
			if( mHole.x > 0 )            iMoves.push_back( Coord::Left()  );
			if( mHole.y > 0 )            iMoves.push_back( Coord::Up()    );
			if( mHole.y < cmWidth - 1 )  iMoves.push_back( Coord::Down()  );
			break;

		case 7:
			if( mHole.x < cmWidth - 1 )  iMoves.push_back( Coord::Right() );
			if( mHole.x > 0 )            iMoves.push_back( Coord::Left()  );
			if( mHole.y < cmWidth - 1 )  iMoves.push_back( Coord::Down()  );
			if( mHole.y > 0 )            iMoves.push_back( Coord::Up()    );
			break;

		case 8:
			if( mHole.x < cmWidth - 1 )  iMoves.push_back( Coord::Right() );
			if( mHole.y > 0 )            iMoves.push_back( Coord::Up()    );
			if( mHole.y < cmWidth - 1 )  iMoves.push_back( Coord::Down()  );
			if( mHole.x > 0 )            iMoves.push_back( Coord::Left()  );
			break;

		case 9:
			if( mHole.x < cmWidth - 1 )  iMoves.push_back( Coord::Right() );
			if( mHole.y > 0 )            iMoves.push_back( Coord::Up()    );
			if( mHole.x > 0 )            iMoves.push_back( Coord::Left()  );
			if( mHole.y < cmWidth - 1 )  iMoves.push_back( Coord::Down()  );
			break;

		case 10:
			if( mHole.x < cmWidth - 1 )  iMoves.push_back( Coord::Right() );
			if( mHole.y < cmWidth - 1 )  iMoves.push_back( Coord::Down()  );
			if( mHole.x > 0 )            iMoves.push_back( Coord::Left()  );
			if( mHole.y > 0 )            iMoves.push_back( Coord::Up()    );
			break;

		case 11:
			if( mHole.x < cmWidth - 1 )  iMoves.push_back( Coord::Right() );
			if( mHole.y < cmWidth - 1 )  iMoves.push_back( Coord::Down()  );
			if( mHole.y > 0 )            iMoves.push_back( Coord::Up()    );
			if( mHole.x > 0 )            iMoves.push_back( Coord::Left()  );
			break;

		/* Up first */ 
		case 12:
			if( mHole.y > 0 )            iMoves.push_back( Coord::Up()    );
			if( mHole.x > 0 )            iMoves.push_back( Coord::Left()  );
			if( mHole.x < cmWidth - 1 )  iMoves.push_back( Coord::Right() );
			if( mHole.y < cmWidth - 1 )  iMoves.push_back( Coord::Down()  );
			break;

		case 13:
			if( mHole.y > 0 )            iMoves.push_back( Coord::Up()    );
			if( mHole.x > 0 )            iMoves.push_back( Coord::Left()  );
			if( mHole.y < cmWidth - 1 )  iMoves.push_back( Coord::Down()  );
			if( mHole.x < cmWidth - 1 )  iMoves.push_back( Coord::Right() );
			break;

		case 14:
			if( mHole.y > 0 )            iMoves.push_back( Coord::Up()    );
			if( mHole.x < cmWidth - 1 )  iMoves.push_back( Coord::Right() );
			if( mHole.x > 0 )            iMoves.push_back( Coord::Left()  );
			if( mHole.y < cmWidth - 1 )  iMoves.push_back( Coord::Down()  );
			break;

		case 15:
			if( mHole.y > 0 )            iMoves.push_back( Coord::Up()    );
			if( mHole.x < cmWidth - 1 )  iMoves.push_back( Coord::Right() );
			if( mHole.y < cmWidth - 1 )  iMoves.push_back( Coord::Down()  );
			if( mHole.x > 0 )            iMoves.push_back( Coord::Left()  );
			break;

		case 16:
			if( mHole.y > 0 )            iMoves.push_back( Coord::Up()    );
			if( mHole.y < cmWidth - 1 )  iMoves.push_back( Coord::Down()  );
			if( mHole.x > 0 )            iMoves.push_back( Coord::Left()  );
			if( mHole.x < cmWidth - 1 )  iMoves.push_back( Coord::Right() );
			break;

		case 17:
			if( mHole.y > 0 )            iMoves.push_back( Coord::Up()    );
			if( mHole.y < cmWidth - 1 )  iMoves.push_back( Coord::Down()  );
			if( mHole.x < cmWidth - 1 )  iMoves.push_back( Coord::Right() );
			if( mHole.x > 0 )            iMoves.push_back( Coord::Left()  );
			break;

		/* Down first */ 
		case 18:
			if( mHole.y < cmWidth - 1 )  iMoves.push_back( Coord::Down()  );
			if( mHole.x > 0 )            iMoves.push_back( Coord::Left()  );
			if( mHole.x < cmWidth - 1 )  iMoves.push_back( Coord::Right() );
			if( mHole.y > 0 )            iMoves.push_back( Coord::Up()    );
			break;

		case 19:
			if( mHole.y < cmWidth - 1 )  iMoves.push_back( Coord::Down()  );
			if( mHole.x > 0 )            iMoves.push_back( Coord::Left()  );
			if( mHole.y > 0 )            iMoves.push_back( Coord::Up()    );
			if( mHole.x < cmWidth - 1 )  iMoves.push_back( Coord::Right() );
			break;

		case 20:
			if( mHole.y < cmWidth - 1 )  iMoves.push_back( Coord::Down()  );
			if( mHole.y > 0 )            iMoves.push_back( Coord::Up()    );
			if( mHole.x > 0 )            iMoves.push_back( Coord::Left()  );
			if( mHole.x < cmWidth - 1 )  iMoves.push_back( Coord::Right() );
			break;

		case 21:
			if( mHole.y < cmWidth - 1 )  iMoves.push_back( Coord::Down()  );
			if( mHole.y > 0 )            iMoves.push_back( Coord::Up()    );
			if( mHole.x < cmWidth - 1 )  iMoves.push_back( Coord::Right() );
			if( mHole.x > 0 )            iMoves.push_back( Coord::Left()  );
			break;

		case 22:
			if( mHole.y < cmWidth - 1 )  iMoves.push_back( Coord::Down()  );
			if( mHole.x < cmWidth - 1 )  iMoves.push_back( Coord::Right() );
			if( mHole.x > 0 )            iMoves.push_back( Coord::Left()  );
			if( mHole.y > 0 )            iMoves.push_back( Coord::Up()    );
			break;

		case 23:
			if( mHole.y < cmWidth - 1 )  iMoves.push_back( Coord::Down()  );
			if( mHole.x < cmWidth - 1 )  iMoves.push_back( Coord::Right() );
			if( mHole.y > 0 )            iMoves.push_back( Coord::Up()    );
			if( mHole.x > 0 )            iMoves.push_back( Coord::Left()  );
			break;
	}
}