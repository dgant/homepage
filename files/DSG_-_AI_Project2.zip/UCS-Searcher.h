#ifndef UCS_SEARCHER_H
#define UCS_SEARCHER_H

#include "Searcher.h"

class UCS_Searcher: public Searcher
{
	public:
		UCS_Searcher( int(* iCostCalculator      )( PuzzleBoard&, Coord ),
		              int(* iHeuristicCalculator )( PuzzleBoard&, Coord ))
			: Searcher(iCostCalculator, iHeuristicCalculator) {}

		virtual void AddOpenNodes( Node* iSource )
		{
			const std::list<Node*>& new_nodes( iSource->GetChildren() );

			for( std::list<Node*>::const_iterator i = new_nodes.begin(); i != new_nodes.end(); ++i )
			{
				// For uniform cost search, insert node in order of cost

				while( (*i)->GetCost() >= static_cast<int>(mOpen.size()) )
				{
					mOpen.resize( mOpen.size() * 2 );
				}

				mOpen[(*i)->GetCost()].push_back( *i );

				++mNumberOfOpenNodes;
			}
		}

		virtual void AddFirstNode( Node* iNode )
		{
			mOpen.resize( iNode->GetCost()+1 );
			mOpen[iNode->GetCost()].push_back( iNode );

			++mNumberOfOpenNodes;
		}
};

#endif