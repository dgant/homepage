#Part of Pynect4
#By Dan Gant
#dan dot gant at gmail

#Width of game board
board_width = 7

#Height of game board
board_height = 6

#Number of consecutive pieces needed for victory
victory_length = 4

# Player names
player_none = ' '
player_a = 'X'
player_b = 'O'