#Part of Pynect4
#By Dan Gant
#dan dot gant at gmail

import constants

def format(arg_game):
    """
    Returns a text-based representation of 'arg_game'
    
    'arg_game' should be a gamestate.GameState
    """
    horizontal_border = '+%s+\n' % ('-' * constants.board_width)
    formatted_board = ''
    formatted_board += horizontal_border
    for row in range(constants.board_height):
        formatted_board += '|'
        for column in range(constants.board_width):
            formatted_board += arg_game.get_piece(column, row)
        formatted_board += '|\n'
    formatted_board += horizontal_border
    formatted_board += ' '
    formatted_board += ''.join(map(str, range(1,constants.board_width+1)))
    formatted_board += ' '
    return formatted_board