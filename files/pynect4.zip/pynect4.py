#Part of Pynect4
#By Dan Gant
#dan dot gant at gmail

import constants
import gamestate
import playerai
import playerhuman
import boardformatter


def main():
    """Pynect4 is an implementation of Connect 4 written in Python."""
    
    game = gamestate.GameState()
    
    #Specify a mapping of (player name):(player object)
    players = {constants.player_a: playerhuman.PlayerHuman(), constants.player_b: playerai.PlayerAI()}
    
    while game.winner == None:
        game.execute_move(players.get(game.current_player).get_move(game))
    
    print boardformatter.format(game)
    
    if game.winner == constants.player_none:
        print 'The game ends in a tie!'
    else:
        print '\nPlayer %s wins!\n' % game.winner
        
        
if __name__ == "__main__":
    main()
