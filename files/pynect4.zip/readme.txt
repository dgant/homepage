Pynect4, an implementation of Connect 4 written in Python
By Dan Gant
dan dot gant at gmail

usage: python pynect4.py