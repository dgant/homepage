#Part of Pynect4
#By Dan Gant
#dan dot gant at gmail

import constants
import random
import boardformatter
import copy

def get_game_id(arg_game):
    """Utility function. Returns a one-to-one identifier for a
    GameState.
    
    For the purposes of this function, games which took different
    orders of moves to arrive at the same position are considered
    identical.
    """
    
    output = ''
    for column in range(constants.board_width):
        for row in range(constants.board_height):
            output += str(arg_game.get_piece(column, row))
    return output
    
class PlayerAI:
    """
    Represents a Player controlled by the computer.
    Implements the get_move method, which is implemented by all Player types.
    """
    
    def __init__(self):
        self._memoized_evaluations_static = {}
        self._memoized_evaluations_minmax = None
        #This property is the depth of the AI search
        #This value can be adjusted to tune the difficulty and speed of
        #the AI
        self.search_depth = 4
        
    def get_move(self, arg_game):
        """
        Returns the AI's chosen move for the current position in a GameState
        
        'arg_game' should be a gamestate.GameState
        """
        
        print boardformatter.format(arg_game)
        print 'Player %s is thinking...' % arg_game.current_player
        
        #Reset the AI's cache of memoized minmax evaluations
        self._memoized_evaluations_minmax = {}
        
        #Because AI calculations are potentially destructive to the
        #game state upon which they operate, operate on a copy of the
        #actual game state
        return self.__select_move(copy.deepcopy(arg_game), self.search_depth)[1]
        
    def __select_move(self, arg_game, arg_search_depth):
        """
        Selects the strongest move for the current player, based on the
        AI's opinion
        
        'arg_game' should be a gamestate.GameState
        'arg_search_depth' is the number of moves to look ahead
        
        Returns, as a tuple, (heuristic, move)
        where 'heuristic' is a unitless measure of the strength of the move.
        Larger values of 'heuristic' favor the current player.
        """
        
        #Estimate the strength of each legal move and return the best
        #(heuristic, move) tuple
        legal_moves = filter(arg_game.can_move, range(constants.board_width))
        candidates = [(self.__evaluate_minmax(arg_game, move, arg_search_depth)
        , move) for move in legal_moves]
        candidates.sort()
        return candidates[-1]

    def __evaluate_minmax(self, arg_game, arg_move, arg_search_depth):
        """
        Evaluates the strength of the specified move upon the current
        game state

        'arg_game' should be a gamestate.GameState
        'arg_move' should be the move to evaluate
        'arg_search_depth' is the number of moves to look ahead
        
        Returns a floating point heuristic
        Larger values of 'heuristic' favor the current player.
        """
        
        #Execute the move and test its consequences
        arg_game.execute_move(arg_move)
        
        if arg_game.winner == constants.player_none:
            #Tie games give a neutral evaluation
            evaluation = 0
            
        elif arg_game.winner != None:
            #Tie games give an arbitrarily large evaluation.
            #The only requirement for this number is that it's
            #much larger than the output of __evaluate_static
            evaluation = 99999

        elif arg_search_depth > 0:
            #Apply min-maxing to look ahead in the game
            id = get_game_id(arg_game)
            if id in self._memoized_evaluations_minmax:
                evaluation = self._memoized_evaluations_minmax[id]
            else:
                evaluation = -self.__select_move(arg_game, arg_search_depth-1)[0]
                self._memoized_evaluations_minmax[id] = evaluation
        else:
            #The AI has exhausted its search depth.
            #Return a static evaluation of the current position
            #based on the pieces on the board
            id = get_game_id(arg_game)
            if id in self._memoized_evaluations_static:
                evaluation = self._memoized_evaluations_static[id]
            else:
                evaluation = -self.__evaluate_static(arg_game)
                self._memoized_evaluations_static[id] = evaluation            
        
        #Return the game state to where it was before, so we can
        #get valid results as recursive calls to this function unwind
        arg_game.undo_move()
        return evaluation

    def __evaluate_static(self, arg_game):
        """
        Evaluates the goodness of the specified GameState

        Returns a floating point heuristic
        Larger values of 'heuristic' favor the current player.
        """

        #Sums the heuristic value of all pieces on the board
        #Opponent's pieces are subtracted from the value
        #Each piece's value increases with:
        #-Proximity to center
        #-Number of adjacent friendly or open squares

        h = 0

        for i in range(0, constants.board_width):
            for j in range(0, constants.board_height):
                if arg_game.get_piece(i, j) != constants.player_none:                  
                    #Value central positions.
                    #Avoid integer rounding bias (in a board that's 6 units tall, the two middle rows are equally "good")
                    #d ranges on (0,1)
                    d = float(min(i,constants.board_width-1-i) + min(j,constants.board_height-1-j)) / float(constants.board_width/2 + constants.board_height/2)

                    #Value friendly or empty neighbors
                    #Note the additional bias towards central placement: pieces in corners or edges have fewer total neighbors
                    #f ranges on (0,1)
                    f = 0.
                    for a in (-1,0,1):
                        for b in (-1,0,1):
                            if (a!=0 or b!= 0) and i+a>=0 and j+b>=0 and i+a<constants.board_width and j+b<constants.board_height:
                                if arg_game.get_piece(i+a, j+b) == arg_game.get_piece(i, j):
                                    f += 1./8.
                                elif arg_game.get_piece(i+a, j+b) == constants.player_none:
                                    f += 1./16.
                        
                    if arg_game.get_piece(i, j) == arg_game.current_player:
                        h += d+f
                    else:
                        h -= d+f
        return h
