#Part of Pynect4
#By Dan Gant
#dan dot gant at gmail

import constants
import boardformatter

class PlayerHuman:
    """Represents a Player controlled by a human.
    
    Implements the get_move method, which is implemented by all Player types.
    """
        
    def get_move(self, arg_game):
        """Prompts the user for a move legal within gamestate.GameState 'arg_game'.
        
        'arg_game' should be a gamestate.GameState
        
        Returns the prompted value.
        """
        
        def get_prompted_move(arg_game):
            try:
                raw_move = raw_input('Enter your move 1-%d, Player %s: ' % (constants.board_width, arg_game.current_player))
                move = int(raw_move) - 1
            except ValueError:
                print 'You must enter a number.'
                return get_prompted_move(arg_game)
                
            if not arg_game.can_move(move):
                print '\'%s\' is not a legal move.' % raw_move
                return get_prompted_move(arg_game)
            
            return move
            
        print boardformatter.format(arg_game)
        return get_prompted_move(arg_game)
        