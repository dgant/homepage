#Part of Pynect4
#By Dan Gant
#dan dot gant at gmail

import constants


def get_other_player_id(arg_player):
    """Returns whichever player is not the specified player"""
    
    if arg_player == constants.player_a:
        return constants.player_b
        
    if arg_player == constants.player_b:
        return constants.player_a
        
    return constants.player_none


class GameState:
    """
    Represents the entire state of a game of Pynect4
    Implements the game's rules
    """
    def __init__(self):
        #Contains the history of moves made as (column, row) pairs
        self._moves_executed = []
        
        #'board' is a list of columns
        #Each column is a list of player ids
        #Column index increases from left to right
        #Row index increases from top to bottom
        #
        #Prefer avoiding direct references to _board.
        #Use get_piece() and set_piece() instead
        #
        self._board = [[constants.player_none for rows in range(constants.board_height)] for columns in range(constants.board_width)]
    
        #This is the winner of the game.
        #
        #None:
        #The game has not ended
        #
        #constants.player_a:
        #The first player has won
        #
        #constants.player_b:
        #The second player has won
        #
        #constants.player_none
        #The game is a tie
        self.winner = None
        
        #The player whose turn it is to move
        self.current_player = constants.player_a
        
    def get_piece(self, arg_column, arg_row):
        """Returns the player who controls the piece at the specified
        column and row
        """
        
        return self._board[arg_column][arg_row]
        
    def set_piece(self, arg_column, arg_row, arg_player):
        """Assigns to 'arg_player' the piece at the specified
        column and row
        """
        
        self._board[arg_column][arg_row] = arg_player
    
    def can_move(self, arg_move):
        """
        Returns true if arg_move is a legal move
        
        'arg_move' should be the index of a column
        """
        
        #Reject moves to nonexistent columns
        if arg_move < 0:
            return False
            
        if arg_move >= constants.board_width:
            return False
        
        #If the top of the specified column is unoccupied,
        #then the move is legal
        return self.get_piece(arg_move, 0) == constants.player_none
        
    def execute_move(self, arg_move):
        """
        Forces the current player to make the specified move
        
        'arg_move' should be the index of a column
        """
        
        #Assign to the current player the lowermost space in the
        #specified column
        for i in reversed(range(0, constants.board_height)):
            if self.get_piece(arg_move, i) == constants.player_none:
                self.set_piece(arg_move, i, self.current_player)
                self._moves_executed.append((arg_move, i))
                break
                
        def get_winner():
            """If the last move made completes the game, returns the winner
            Otherwise, returns None
            """
            
            #Identify the coordinates of the last move made
            x = self._moves_executed[-1][0]
            y = self._moves_executed[-1][1]
            
            #Identify the player whose pieces we're looking for
            candidate = self.get_piece(x, y)
                
            #Look in every direction to find enough consecutive pieces
            #to declare a winner
            #
            #Note that current algorithm looks horizontally twice as a
            #side effect of the implementation
            for i in [-1,0,1]:
                for j in [0,1]:
                    if (i != 0) or (j != 0):
                        connected = 1
                        for s in [-1,1]:
                            for n in range(1, constants.victory_length):
                                xp = x+i*s*n
                                yp = y+j*s*n
                                if (xp >= 0) and (yp >= 0) and \
                                (xp < constants.board_width) and \
                                (yp < constants.board_height) and \
                                (self.get_piece(xp, yp) == candidate):
                                    connected += 1
                                else:
                                    break
                        if connected >= constants.victory_length:
                            return candidate
            #Is the game a draw?
            if len(self._moves_executed) == \
            constants.board_width * constants.board_height:
                return constants.player_none
            return None
        
        self.winner = get_winner()
        self.current_player = get_other_player_id(self.current_player)
        
    def undo_move(self):
        """Undoes the last move executed"""
        
        move = self._moves_executed.pop()
        self.set_piece(move[0], move[1], constants.player_none)
        self.current_player = get_other_player_id(self.current_player)
        self.winner = None
        