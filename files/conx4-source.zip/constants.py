gcDebug = False

gcWidth = 7                  #Width of game board
gcHeight = 6                 #Height of game board
gcVictory = 4                #Number of consecutiveMatches pieces needed for victory
gcNil = -1                   #Value of empty board spaces
gcPlayerHuman = 0
gcPlayerComputer = 1
gcRed = 0                    #Index of red player
gcBlue = 1                   #Index of blue player

gcColorKey =      (255,0,255)    #Default color key
gcColorRed =      (255,192,192)  #Red font color
gcColorBlue =     (192,192,255)  #Blue font color
gcColorYellow =   (255,255,192)  #Yellow font color
gcColorGrey =     (224,224,224)  #Grey font color
gcColorDarkRed =  (192,96,96)    #Dark red font color
gcColorDarkBlue = (96,96,192)    #Dark blue font color
gcColorDarkGrey = (128,128,128)  #Dark grey font color

gcResolution = (800,600)
gcGameName = "ConX4"

gcPathImages = "gfx"
gcPathSounds = "sfx"
gcPathFonts = "fonts"

def GetOtherPlayer(inPlayerNum):
        """
        Given any player's index, return the other player's index
        """
        if inPlayerNum == gcRed:    return gcBlue
        elif inPlayerNum == gcBlue: return gcRed
        else:                       return gcNil
