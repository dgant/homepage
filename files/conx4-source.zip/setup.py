from distutils.core import setup
import py2exe

setup(console=['conx4.py'])
