from utils import *
import os, sys, copy
import pygame
from pygame.locals import *

###################
# UI base classes #
###################

class IWidget:
    """
    Generic interface for game objects
    """
    def __init__(self, inID):
        self.id = inID
        self.listeners = set()
        self.playsounds = True
    def Update(self): pass
    def HandleMouseDown(self): return False
    def HandleMouseUp(self): return False
    def Draw(self,inSurface,inOffset=(0,0)): pass
    def GetID(self): return self.id
    def RegisterListener(self, inListener):   self.listeners.add( inListener )
    def UnregisterListener(self, inListener): self.listeners.discard( inListener )
    def NotifyListeners( self, inMessage ):
        for listener in self.listeners:
            listener.Notify( inMessage )

class CompoundMessage:
    """
    For syntactical ease of use, the notification system is supposed be used to pass strings. When more complicated data needs to be sent, CompoundMessage can be used in the place of a string. 
    """
    def __init__( self, inMessage, inContent ): self.message, self.content = inMessage, inContent
    def __eq__( self, inComparison ): return self.message == inComparison
    def __str__( self ): return self.message
    
class Scene(IWidget):
    """
    Stores and organizes a collection of widgets.
    """
    def __init__( self, inID ):
        IWidget.__init__( self, inID )
        self.widgets = []
        self.activeWidget = None
        self.swallowIO = False

    def Update( self ):
        for w in self.widgets: w.Update()
        
    def HandleMouseDown( self ):
        for w in self.widgets:
            if w.HandleMouseDown(): return True
        return self.swallowIO
    
    def HandleMouseUp( self ):
        for w in self.widgets:
            if w.HandleMouseUp(): return True
        return self.swallowIO
    
    def Draw( self, inSurface, inOffset=(0,0) ):
        for w in self.widgets:
            w.Draw(inSurface, inOffset)
            
    def SetSwallowIO(self, inToggle):
        self.swallowIO = inToggle
        
    def AddWidget(self,inWidget):
        self.widgets.append(inWidget)
        
    def GetWidget(self,inWidgetID):
        for widget in self.widgets:
            if widget.GetID() == inWidgetID:
                return widget
        return None
    
    def RemoveWidget(self, inWidgetID, inRemoveAll=False):
        "If inRemoveAll is set, removes all widgets matching the given ID. Otherwise, removes only the first such widget."
        #Iterate backwards, on the assumption that more recently added widgets are those most likely to be removed
        for i in range(self.widgets-1,-1,-1): 
            if self.widgets[i].GetID == inWidgetID: self.widgets.pop[i]
            if not inRemoveAll: return

###############
# UI elements #
###############

class Image(IWidget):
    """
    Displays a still image
    """
    def __init__( self, inID, inBounds, inImage ):
        IWidget.__init__(self, inID)
        self.bounds, self.image = inBounds, inImage
    def Draw( self, inSurface, inOffset=(0,0)):
        inSurface.blit(self.image, self.image.get_rect().move(self.bounds[0]+inOffset[0],self.bounds[1]+inOffset[1]))
    
class StaticImage(Image):
    """
    Displays a still image, given the name of a loaded image resource
    """
    def __init__( self, inID, inBounds, inImageName ):
        Image.__init__(self, inID, inBounds, GetResource(inImageName))
        
class TextImage(Image):
    """
    Renders, aligns, and displays text
    """
    def __init__(self, inID, inBounds, inFontName, inText, inColor, inAntialias=True):
        self.font = GetResource(inFontName)
        Image.__init__(self, inID, inBounds, self.font.render(inText, inAntialias, inColor))
        self.alignment = (0,0)
        self.offset = (0,0)
        self.SetOffset()
        
    def SetText( self, inText, inColor, inAntialias=True ):
        self.image = self.font.render(inText, inAntialias, inColor)
        return self
        
    def AlignLeft( self ):   return self.AlignXY( (0,self.alignment[1]) )
    def AlignCenter( self ): return self.AlignXY( (1,self.alignment[1]) )
    def AlignRight( self ):  return self.AlignXY( (2,self.alignment[1]) )
    def AlignTop( self ):    return self.AlignXY( (self.alignment[0],0) )
    def AlignMiddle( self ): return self.AlignXY( (self.alignment[0],1) )
    def AlignBottom( self ): return self.AlignXY( (self.alignment[0],2) )
    
    def AlignXY( self, inAlignment ):
        self.alignment = inAlignment
        self.SetOffset()
        return self
    
    def SetOffset( self ):
        self.offset = ( (self.bounds[2]-self.image.get_rect().width)*self.alignment[0]/2, (self.bounds[3]-self.image.get_rect().height)*self.alignment[1]/2 )

    def Draw( self, inSurface, inOffset=(0,0) ):
        Image.Draw( self, inSurface, (inOffset[0]+self.offset[0], inOffset[1]+self.offset[1]) )
            
class Button(IWidget):
    """
    Standard UI button.
    """
    def __init__( self, inID, inBounds, inImageNames, inSoundNameMouseover, inSoundNameMousedown, inSoundNameMouseup ):
        IWidget.__init__(self, inID)
        self.bounds = Rect(inBounds)
        self.imageNormal       = GetResource( inImageNames[0] )
        self.imageHot          = GetResource( inImageNames[1] )
        self.imageNormalDown   = GetResource( inImageNames[2] )
        self.imageHotDown      = GetResource( inImageNames[3] )
        self.imageDisabled     = GetResource( inImageNames[4] )

        self.soundMouseover = GetResource( inSoundNameMouseover )
        self.soundMousedown = GetResource( inSoundNameMousedown )
        self.soundMouseup   = GetResource( inSoundNameMouseup   )
        
        self.isHot = False
	self.isDown = False
	self.isEnabled = True
	
        self.text = None
        self.textOffsetNormal = None
        self.textOffsetDown = None

    def AddTextImage( self, inTextImage, inOffsetNormal=(0,0), inOffsetDown=(0,0) ):
        self.text = inTextImage
        self.textOffsetNormal = inOffsetNormal
        self.textOffsetDown = inOffsetDown
        return self

    def Activate( self ):
        self.NotifyListeners( self.id )

    def SetEnable(self, inEnable):
        self.isEnabled = inEnable
        
    def Update(self):
        playsound = self.playsounds and not self.isHot and not self.isDown
	self.isHot = self.isEnabled and self.bounds.collidepoint(pygame.mouse.get_pos())
	if playsound and self.isHot and self.soundMouseover:
            self.soundMouseover.play() 

    def HandleMouseDown(self):
        if self.isHot:
            self.isDown = True
            if self.soundMousedown and self.playsounds: self.soundMousedown.play()
        return self.isDown

    def HandleMouseUp(self):
        if self.isDown:
            self.isDown = False
            if self.isHot:
                self.Activate()
                if self.soundMouseup and self.playsounds: self.soundMouseup.play()
                return True
        return False

    def Draw(self, inSurface, inOffset=(0,0)):
        if self.isEnabled:
            if self.isHot:
                if self.isDown:  image = self.imageHotDown
                else:            image = self.imageHot
            else:
                if self.isDown:  image = self.imageNormalDown
                else:            image = self.imageNormal
        else: image = self.imageDisabled

        inSurface.blit(image, image.get_rect().move( self.bounds[0]+inOffset[0], self.bounds[1]+inOffset[1] ))

        if self.text:
            if self.isDown: offset = self.textOffsetDown
            else:           offset = self.textOffsetNormal        
            self.text.Draw( inSurface, (inOffset[0]+offset[0],inOffset[1]+offset[1]) )

class RadioButton(Button):
    """
    Standard UI radio button.
    """
    def __init__( self, inID, inBounds, inImageNames, inSoundNameMouseover, inSoundNameMousedown, inSoundNameMouseup ):
        Button.__init__( self, inID, inBounds, inImageNames, inSoundNameMouseover, inSoundNameMousedown, inSoundNameMouseup )

    def Activate( self ):
        self.isDown = True
        self.NotifyListeners( self.id )

    def Reset(self): self.isDown = False
    
    def HandleMouseDown(self):
        if self.isHot and not self.isDown:
            self.Activate()
            if self.soundMousedown and self.playsounds: self.soundMousedown.play()
            return True
        return False

    def HandleMouseUp(self): return False

class RadioButtonGroup(IWidget):
    """
    Maintains a collection of radio buttons
    """
    def __init__( self, inID, inRadioButtons=[] ):
        IWidget.__init__( self, inID )
        self.radioButtons = []

        for button in inRadioButtons:
            self.AddRadioButton( button )

    def AddRadioButton( self, inRadioButton ):
        self.radioButtons.append( inRadioButton )
        inRadioButton.RegisterListener( self )

    def Notify( self, inMessage ):
        self.NotifyListeners( inMessage )
        for button in self.radioButtons:
            if button.GetID() != inMessage:
                button.Reset()

class ScrollBar(IWidget):
    """
    Standard UI scroll bar
    """
    def __init__( self, inID, inBarBounds, inBarImage, inButtonBounds, inButtonImages, inSoundNameMouseover, inSoundNameMousedown, inSoundNameMouseup ):
        IWidget.__init__( self, inID )
        self.barBounds = inBarBounds
        self.barImage = inBarImage
        
        self.button = Button( None, inButtonBounds, inButtonImages, inSoundNameMouseover, inSoundNameMousedown, inSoundNameMouseup )

class BoardDisplay(IWidget):
    """
    Graphically depicts the board
    """
    def __init__( self, inID, inBounds, inBoardOrigin, inStoneDimensions, inImageBoard, inImageRed, inImageBlue, inStoneSound, inAttachedGame ):
        IWidget.__init__( self, inID )
        self.bounds = inBounds
        self.boardOrigin = inBoardOrigin
        self.stoneDimensions = inStoneDimensions

        self.imageBoard = GetResource( inImageBoard )
        self.imageRed = GetResource( inImageRed )
        self.imageBlue = GetResource( inImageBlue )

        self.stoneSound = GetResource( inStoneSound )

        self.attachedGame = inAttachedGame
    
    def Draw( self, inSurface, inOffset=(0,0) ):
        """
        Draws board and all stones
        """
        inSurface.blit(self.imageBoard, self.imageBoard.get_rect().move( self.bounds[0]+inOffset[0], self.bounds[1]+inOffset[1] ))

        for i in range(gcWidth):
            for j in range(gcHeight):
                image = None
                if self.attachedGame.GetStone(i,j) == gcRed:     image = self.imageRed
                elif self.attachedGame.GetStone(i,j) == gcBlue:  image = self.imageBlue
                if image:
                    inSurface.blit(image, image.get_rect().move( self.bounds[0]+self.boardOrigin[0]+inOffset[0]+i*self.stoneDimensions[0], self.bounds[1]+self.boardOrigin[1]+inOffset[1]+j*self.stoneDimensions[1] ))

    def HandleMouseDown( self ):
        """
        Returns true and notifies if user clicked on the board.
        """
        p = pygame.mouse.get_pos()
        x = (p[0] - self.boardOrigin[0])/self.stoneDimensions[0]
        y = (p[1] - self.boardOrigin[1])/self.stoneDimensions[1]
        if 0 <= x and 0 <= y and x < gcWidth and y < gcHeight:
            self.NotifyListeners( CompoundMessage( self.GetID(), x ))
            return True 
        return False
