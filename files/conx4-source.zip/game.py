from constants import *
from ai import *
from board import *
from view import *
import copy
import threading

class Game(IWidget):
    """
    Stores game data and handles game logic
    """
    def __init__(self):
        self.board = Board()
        self.playerTypes = [gcPlayerHuman, gcPlayerComputer] #Dependent on gcRed == 0, gcBlue == 1
        self.view = None
        self.aiDepth = 0
        self.Reset()

    def Reset(self):
        self.aithread = None
        self.winner = None
        self.turn = 0
        self.currentPlayer = gcRed
        self.board.Reset()
        if self.view: self.view.UpdateStatus()
    
    def SetView(self, inView):
        self.view = inView
        if self.view: self.view.UpdateStatus()
    
    def Update(self):
        """
        Runs regular update of game logic.
        Only time-dependent update right now is starting and waiting for the AI
        """
        if self.winner == None and self.playerTypes[self.currentPlayer] == gcPlayerComputer and not self.aithread:
            #If the game is in progress, and it's an AI player's turn, get an AI move.
            self.aithread = AIThread(self.currentPlayer, copy.deepcopy(self.board), self.aiDepth)
            self.aithread.start()
        if self.aithread:
            #If an AI thread has been started, check whether it has finished running
            if not self.aithread.lock.locked():
                #The AI script should be complete. Attempt to access and execute the AI's move.
                self.aithread.lock.acquire()
                try:
                    if self.aithread.move != None:
                        self.ApplyMove(self.aithread.move)
                except Exception: pass #!!! Figure out the expected exception here, if any
                #If a move somehow wasn't selected, the AI will be run again.
                self.aithread = None #Is this safe?

    def ApplyMove(self, inMoveX):
        """
        Attempts to execute a move, and updates game state accordingly.
        """
        self.turn += 1
        if self.winner == None and self.board.CanMakeMove(inMoveX):
            if self.board.CheckWin(self.board.MakeMove(inMoveX, self.currentPlayer)):
                self.winner = self.currentPlayer
            elif self.turn == gcWidth * gcHeight:
                self.winner = gcNil
            self.currentPlayer = GetOtherPlayer(self.currentPlayer)
            if self.view: self.view.UpdateStatus("moved")
            return True

    def SetPlayerType(self, inPlayerIndex, inPlayerType):
        self.playerTypes[inPlayerIndex] = inPlayerType
        if inPlayerType != gcPlayerComputer: self.aithread = None #!!! This may be trouble
        if self.view: self.view.UpdateStatus()
            
    ##########################
    # Interface for viewport #
    ##########################

    def GetStone(self, inX, inY):      return self.board.At(inX, inY)
    def GetWinner(self):               return self.winner
    def GetCurrentPlayer(self):        return self.currentPlayer 
    def GetPlayerType(self, inPlayer): return self.playerTypes[inPlayer]
    
    def ApplyMoveUI(self, inMoveX):
        """
        Accept an attempted move from the user.
        Returns true if move was executed.
        """
        if self.playerTypes[self.currentPlayer] == gcPlayerHuman:
            return self.ApplyMove( inMoveX )
        return False

    def ResetUI(self):
        self.Reset()

    def SetPlayerTypeUI(self, inPlayerIndex, inPlayerType):
        self.SetPlayerType( inPlayerIndex, inPlayerType )

    def SetAIDifficulty(self, inDepth):
        self.aiDepth = inDepth
        if self.view: self.view.UpdateStatus()
        
