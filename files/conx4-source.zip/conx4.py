from constants import *
from game import *
from view import *
import os, sys
import pygame
from pygame.locals import *

def main():
    pygame.init()
    screen = pygame.display.set_mode(gcResolution)
    pygame.display.set_caption(gcGameName)

    clock = pygame.time.Clock()

    game = Game()
    view = View(game)
    game.SetView(view)
    
    while True:
        clock.tick(20)

        game.Update()
        view.Update()

        if view.QuitSelected(): return
        
        for event in pygame.event.get():
            if event.type == QUIT:              return
            elif event.type == MOUSEBUTTONDOWN: view.HandleMouseDown()
            elif event.type == MOUSEBUTTONUP:   view.HandleMouseUp()

        view.Draw(screen)
        pygame.display.flip()
        
if __name__ == "__main__": main()
