from constants import *
from board import *
import threading
import random
import os, sys
import pygame
from pygame.locals import *
 
class AIThread(threading.Thread):
    """
    Gets an AI move for a given board position
    """
    
    def __init__( self, inNumber, inBoard, inMaxDepth ):
        threading.Thread.__init__(self)
        self.number = inNumber
        self.board = inBoard
        self.maxDepth = inMaxDepth
        self.move = None
        self.lock = threading.Lock()
        
    def run( self ):
        if not self.lock.locked():
            self.lock.acquire()
            self.move = self.GetAIMove(self.board)
            self.lock.release()
        
    def GetAIMove(self, inBoard):
        """
        Determines the "best" move for the given board
        Very simple depth-limited depth-first heuristic search
        Heuristics range on [-9999,9999]

        Returns chosen move
        """
            
        #Store candidate moves in pairs of [move,heuristic]
        candidates = []
        
        for i in range(gcWidth):
            if inBoard.CanMakeMove(i):
                candidates.append( [i, self.GetEval(inBoard, i, self.number, 0)] )

        if len(candidates) == 0:
            #There should be at least one candidate!
            return 0

        bestEval = -9999
        for entry in candidates:
            bestEval = max(entry[1], bestEval)
        
        for entry in candidates:
            if entry[1] == bestEval:
                return entry[0]

    def GetEval( self, inBoard, inMove, inPlayerNum, inDepth ):
        """
        Evaluates the strength of the chosen move

        Returns heuristic
        """
        
        #Execute move on test board. Then check if it's a winning move.
        squarePlayed = inBoard.MakeMove(inMove, inPlayerNum)
        
        if inBoard.CheckWin(squarePlayed):
            finalEval = 9999

        elif inDepth == self.maxDepth:
            #Maximum search depth reached. Just return position heuristic.
            finalEval =  self.GetPositionEval(inPlayerNum, inBoard)

        else:            
            #Get evaluation after best opponent move in this position
            candidates = []            
            for i in range(gcWidth):
                if inBoard.CanMakeMove(i):
                    candidates.append( 0 - self.GetEval(inBoard, i, GetOtherPlayer(inPlayerNum), inDepth+1 ))
                    
            if len(candidates) == 0:
                #There are no moves left; this position is drawn
                finalEval =  0
            else:
                #Assume opponent will use best move possible
                finalEval = min(candidates)
                
        inBoard.UndoMove(inMove)
        return finalEval

    def GetMoveEval(self, inSquare, inPlayerNum, inBoard):
        """
        Evaluates the strength of a move

        Returns heuristic
        """
        #Favor moves:
        #-Close to the center of the board, especially horizontally
        #-On top of enemy pieces, diagonally or vertically
        #-Randomly, to create non-deterministic play
        #
        #Each measurement is weighed by a factor that ranges from 0.0 to 1.0,
        #allowing factors to be compared in a variety of ways
        
        x = inSquare[0]
        y = inSquare[1]
        
        distFactor = float(abs(x-gcWidth/2) + abs(y-gcHeight/2)) / float((gcWidth+gcHeight)/2)
        
        coverFactor = 0.
        if y < gcHeight - 1:
            for i in (-1,0,1):
                if (x+i >= 0) and (x+1 < gcWidth) and (inBoard.stones[x+i][y+1] == GetOtherPlayer(inPlayerNum)):
                    coverFactor += 1./3.

        randFactor = 0.75 + random.random()/4.

        h = (randFactor + 1.) * (2*coverFactor + 1.) * (distFactor +1.)

        return int(h*10)

    def GetPositionEval(self, inPlayerNum, inBoard):
        """
        Evaluates the current board position for inPlayerNum

        Returns heuristic
        """

        #Sums the heuristic value of all pieces on the board
        #Opponent's pieces are subtracted from the value
        #Each piece's value increases with:
        #-Proximity to center
        #-Number of adjacent friendly or open squares
        #
        #Puts a random weight on the final value to create non-deterministic play

        h = 0

        for i in range(0, gcWidth):
            for j in range(0, gcHeight):
                if inBoard.stones[i][j] != gcNil:                  
                    #Value central positions.
                    #Avoid integer rounding bias (in a board that's 6 units tall, the two middle rows are equally "good")
                    #d ranges on (0,1)
                    d = float(min(i,gcWidth-1-i) + min(j,gcHeight-1-j)) / float(gcWidth/2 + gcHeight/2)

                    #Value friendly or empty neighbors
                    #Note the additional bias towards central placement: pieces in corners or edges have fewer total neighbors
                    #f ranges on (0,1)
                    f = 0.
                    for a in (-1,0,1):
                        for b in (-1,0,1):
                            if (a!=0 or b!= 0) and i+a>=0 and j+b>=0 and i+a<gcWidth and j+b<gcHeight:
                                if inBoard.stones[i+a][j+b] == inBoard.stones[i][j]:  f += 1./8.
                                elif inBoard.stones[i+a][j+b] == gcNil:               f += 1./16.
                        
                    if inBoard.stones[i][j] == inPlayerNum:  h += d+f
                    else:                                    h -= d+f
        return h * (.5 + random.random()*.5)
