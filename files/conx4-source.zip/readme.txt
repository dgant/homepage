Source code and content released under GPL (General Public License).
Runs under Python 2.4.4 with Pygame 1.7.1 installed.
Compiled version created with Py2exe 0.6.6