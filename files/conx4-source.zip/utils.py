from constants import *
import os, sys
import pygame
from pygame.locals import *

#######################
# Resource management #
#######################

gResources = {None: None} #Initialize the None key; otherwise it may be overwritten!

def AddResource( inResourceKey, inResource ):
    if gResources.get(inResourceKey):
        #There already is a resource of that key. Throw exception?
        if gcDebug:
            print "DEBUG: Attempted to add resource with existing name: " + str(inResourceKey)
            print "DEBUG: Current resource keys:"
            for key in gResources.keys(): print "DEBUG: " + str(key)
    else:
      gResources[inResourceKey] = inResource

def GetResource( inResourceKey ):
    #This throws if resource isn't found
    return gResources[inResourceKey]

####################################################
# Utilities for loading various kinds of resources #
####################################################

def LoadImage( inResourceKey, inFilename, inColorKey=None ):
    """
    Loads an image and inserts it into resource dict
    """
    try:
        image = pygame.image.load(os.path.join(gcPathImages, inFilename))
        image = image.convert()
        if inColorKey:
            image.set_colorkey(inColorKey, RLEACCEL)
        AddResource( inResourceKey, image )
    except Exception:
        if gcDebug:
            print "DEBUG: Can't load ", inResourceKey, " from ", inFilename

class FakeSound:
    """
    Default sound type. Used when a sound can not be loaded.
    """
    def play(self): pass

def LoadSound( inResourceKey, inFilename ):
    """
    Loads a sound and inserts it into resource dict
    """
    if pygame.mixer:
        try:
            snd = pygame.mixer.Sound(os.path.join(gcPathSounds, inFilename))
        except pygame.error, message:
            if gcDebug:
                print "DEBUG: Can't load ", inResourceKey, " from ", inFilename
            snd = FakeSound()
    else:
        if gcDebug:
            print "DEBUG: PyGame mixer not loaded; can't load ", inResourceKey, " from ", inFilename
        snd = FakeSound()
    AddResource( inResourceKey, snd )

def LoadFont( inResourceKey, inFilename, inFontSize ):
    """
    Loads a font and inserts it into resource dict
    """
    if pygame.font:
        try:
            f = pygame.font.Font(inFilename, inFontSize)
            AddResource( inResourceKey, f )
        except pygame.error, message:
                if gcDebug:
                    print "DEBUG: Can't load ", inResourceKey, " from ", inFilename, message
    else:
        print "DEBUG: PyGame font module not enabled; can't load ", inResourceKey, " from ", inFilename
