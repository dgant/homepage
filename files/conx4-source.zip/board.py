from constants import *
import copy
import os, sys
import pygame

class Board:
    """
    Stores and provides methods for manipulating game board
    """
    def __init__(self):
        # Board orientation:
        # (0,0) (1,0) (2,0)
        # (0,1) (1,1) (2,1)
        # (0,2) (1,2) (2,2)
    
        self.stones = []
        column = []
        for j in range(gcHeight): column.append(None)
        for i in range(gcWidth):  self.stones.append(copy.deepcopy(column))
       
        self.Reset()

    def At(self,inX,inY): return self.stones[inX][inY]
    
    def Reset(self):
        """
        Resets the board for a new game
        """
        for i in range(gcWidth):
            for j in range(gcHeight):
                self.stones[i][j] = gcNil
                
    def CanMakeMove(self, inMoveX):
        """
        Returns true if inMoveX is a legal move 
        """
        return 0 <= inMoveX < gcWidth and self.stones[inMoveX][0] == gcNil

    def CanUndoMove(self, inMoveX):
        """
        Returns true if inMoveX can be undone
        """
        return 0 <= inMove < gcWidth and self.stones[inMove+(gcWidth*(gcHeight-1))] == gcNil
   
    def MakeMove(self, inMoveX, inPlayer):
        """
        Executes inMoveX
        
        Returns location where move was made, as a tuple

        Assumes inMoveX is a legal move!
        """
        for i in range(gcHeight-1, -1, -1):
            if self.stones[inMoveX][i] == gcNil:
                self.stones[inMoveX][i] = inPlayer
                return inMoveX, i
            
    def UndoMove(self, inMoveX):
        """
        Undoes inMoveX
        
        Returns location where undo was made, as a tuple

        Assumes inMoveX can be undone!
        """
        i = 0
        while i < gcHeight :
            if self.stones[inMoveX][i] != gcNil:
                self.stones[inMoveX][i] = gcNil
                return inMoveX, i
            i += 1

    def CheckWin(self, inLocation):
        """
        Returns true if there is a winning length of pieces intersecting inLocation
        """
        
        #Identify the player to match
        owner = self.stones[inLocation[0]][inLocation[1]]

        #Are we looking at an empty square?
        if owner == gcNil:
            return 0

        x = inLocation[0]
        y = inLocation[1]

        #Look in every direction to find a win
        #(note that current algorithm looks horizontally twice as a side effect of the implementation)
        for i in [-1,0,1]:
            for j in [0,1]:
                if (i!=0) or (j!=0):
                    connected = 1
                    for s in [-1,1]:
                        for n in range(1,gcVictory):
                            xp = x+i*s*n
                            yp = y+j*s*n
                            if (xp>=0) and (yp>=0) and (xp<gcWidth) and (yp<gcHeight) and (self.stones[xp][yp]==owner):
                                connected += 1
                            else:
                                break
                    if connected >= gcVictory:
                        return True
        return False
