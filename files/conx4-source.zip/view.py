from constants import *
from utils import *
from game import *
from ui import *
import os, sys
import pygame
from pygame.locals import *

class View(Scene):
    """
    Contains, displays, and instantiates user interface elements.
    """
    def __init__(self, inGame):
        Scene.__init__(self, "View")

        self.attachedGame = inGame
        self.quitSelected = False
                
        #Load resources
        LoadImage("ButtonUp", "buttonup.png", gcColorKey)
        LoadImage("ButtonDown", "buttondown.png", gcColorKey)
        LoadImage("ButtonHot", "buttonhot.png", gcColorKey)
        LoadImage("Background", "background.png", gcColorKey)
        LoadImage("RadioDeselected", "radiodeselected.png", gcColorKey)
        LoadImage("RadioSelected", "radioselected.png", gcColorKey)
        LoadImage("RadioHot", "radiohot.png", gcColorKey)
        LoadImage("RadioPressed", "radiopressed.png", gcColorKey)
        LoadImage("Board", "board.png", gcColorKey)
        LoadImage("StoneRed", "stonered.png", gcColorKey)
        LoadImage("StoneBlue", "stoneblue.png", gcColorKey)
        LoadSound("Button mouseover", "over.wav")
        LoadSound("Button click", "click.wav")
        LoadSound("Stone lands", "land.wav")
        LoadSound("Victory", "win.wav")
        LoadSound("Defeat", "lose.wav")
        LoadFont("Font48", "AurulentSans-Regular.otf", 48)
        LoadFont("Font32", "AurulentSans-Regular.otf", 32)
        LoadFont("Font20", "AurulentSans-Regular.otf", 20)

        self.soundWin = GetResource("Victory")
        self.soundLose = GetResource("Defeat")
        self.soundStone = GetResource("Stone lands")

        #Create UI
        self.AddWidget( StaticImage( "image-background",              (0,0,800,600),    "Background" ))
        self.AddWidget( TextImage(   "text-logo",                     (612,12,176,64),  "Font48", gcGameName, gcColorYellow).AlignCenter().AlignMiddle() )
        t =             Button(      "button-new",                    (612,88,176,64),  ("ButtonUp", "ButtonHot", "ButtonDown", "ButtonDown", "ButtonUp"), "Button mouseover", "Button click", "Button click" )
        t.AddTextImage( TextImage(   "button-new-text",               (612,88,176,64),  "Font20", "New", gcColorGrey).AlignCenter().AlignMiddle(), (0,0), (0,4) )
        t.RegisterListener( self )
        self.AddWidget( t )
        t =             Button(      "button-quit",                   (612,164,176,64), ("ButtonUp", "ButtonHot", "ButtonDown", "ButtonDown", "ButtonUp"), "Button mouseover", "Button click", "Button click" )
        t.AddTextImage( TextImage(   "button-quit-text",              (612,164,176,64), "Font20", "Quit", gcColorGrey).AlignCenter().AlignMiddle(), (0,0), (0,4) )
        self.AddWidget( t )
        t.RegisterListener( self )
        self.AddWidget( TextImage(   "text-redplayerproperties",      (612,250,176,32), "Font20", "Red player:", gcColorRed).AlignLeft().AlignMiddle() )
        t =             RadioButton( "radio-redplayerhuman",          (612,286,176,24), ("RadioDeselected", "RadioHot", "RadioSelected", "RadioSelected", "RadioDeselected"), "Button mouseover", "Button click", "Button click" )
        t.AddTextImage( TextImage(   "radio-redplayerhuman-text",     (612,286,176,24), "Font20", "Human", gcColorGrey).AlignLeft().AlignMiddle(), (32,0), (32,0) )
        self.AddWidget( t )
        t =             RadioButton( "radio-redplayercomputer",       (612,310,176,24), ("RadioDeselected", "RadioHot", "RadioSelected", "RadioSelected", "RadioDeselected"), "Button mouseover", "Button click", "Button click" )
        t.AddTextImage( TextImage(   "radio-redplayercomputer-text",  (612,310,176,24), "Font20", "Computer", gcColorGrey).AlignLeft().AlignMiddle(), (32,0), (32,0) )
        self.AddWidget( t )

        self.AddWidget( TextImage(   "text-blueplayerproperties",     (612,346,176,32), "Font20", "Blue player:", gcColorBlue).AlignLeft().AlignMiddle() )
        t =             RadioButton( "radio-blueplayerhuman",         (612,382,176,24), ("RadioDeselected", "RadioHot", "RadioSelected", "RadioSelected", "RadioDeselected"), "Button mouseover", "Button click", "Button click" )
        t.AddTextImage( TextImage(   "radio-blueplayerhuman-text",    (612,382,176,24), "Font20", "Human", gcColorGrey).AlignLeft().AlignMiddle(), (32,0), (32,0) )
        self.AddWidget( t )
        t =             RadioButton( "radio-blueplayercomputer",      (612,406,176,24), ("RadioDeselected", "RadioHot", "RadioSelected", "RadioSelected", "RadioDeselected"), "Button mouseover", "Button click", "Button click" )
        t.AddTextImage( TextImage(   "radio-blueplayercomputer-text", (612,406,176,24), "Font20", "Computer", gcColorGrey).AlignLeft().AlignMiddle(), (32,0), (32,0) )
        self.AddWidget( t )
        self.AddWidget( TextImage(   "text-difficulty",               (612,442,176,32), "Font20", "Computer difficulty:", gcColorYellow).AlignLeft().AlignMiddle() )

        self.AddWidget( TextImage(   "text-difficulty-easy",          (612,478,40,24), "Font20", "Easy", gcColorGrey).AlignLeft().AlignMiddle() )
        self.AddWidget( TextImage(   "text-difficulty-hard",          (748,478,40,24), "Font20", "Hard", gcColorGrey).AlignRight().AlignMiddle() )
        self.AddWidget( RadioButton( "radio-difficulty-2",            (664,478,24,24), ("RadioDeselected", "RadioHot", "RadioSelected", "RadioSelected", "RadioDeselected"), "Button mouseover", "Button click", "Button click" ))
        self.AddWidget( RadioButton( "radio-difficulty-3",            (688,478,24,24), ("RadioDeselected", "RadioHot", "RadioSelected", "RadioSelected", "RadioDeselected"), "Button mouseover", "Button click", "Button click" ))
        self.AddWidget( RadioButton( "radio-difficulty-4",            (712,478,24,24), ("RadioDeselected", "RadioHot", "RadioSelected", "RadioSelected", "RadioDeselected"), "Button mouseover", "Button click", "Button click" ))
        
        self.AddWidget( TextImage(   "text-soundtoggle",              (612,514,176,32), "Font20", "Sound:", gcColorYellow).AlignLeft().AlignMiddle() )
        t =             RadioButton( "radio-soundon",                 (612,552,76,24), ("RadioDeselected", "RadioHot", "RadioSelected", "RadioSelected", "RadioDeselected"), "Button mouseover", "Button click", "Button click" )
        t.AddTextImage( TextImage(   "radio-soundon-text",            (612,552,76,24), "Font20", "On", gcColorGrey).AlignLeft().AlignMiddle(), (32,0), (32,0) )
        self.AddWidget( t )
        t =             RadioButton( "radio-soundoff",                (712,552,76,24), ("RadioDeselected", "RadioHot", "RadioSelected", "RadioSelected", "RadioDeselected"), "Button mouseover", "Button click", "Button click" )
        t.AddTextImage( TextImage(   "radio-soundoff-text",           (712,552,76,24), "Font20", "Off", gcColorGrey).AlignLeft().AlignMiddle(), (32,0), (32,0) )
        self.AddWidget( t )

        t = RadioButtonGroup( "radiogroup-redplayer",  [self.GetWidget("radio-redplayerhuman"),  self.GetWidget("radio-redplayercomputer")]  )
        t.RegisterListener( self )
        self.AddWidget( t )
        t =  RadioButtonGroup( "radiogroup-blueplayer", [self.GetWidget("radio-blueplayerhuman"), self.GetWidget("radio-blueplayercomputer")] )
        t.RegisterListener( self )
        self.AddWidget( t )
        t = RadioButtonGroup( "radiogroup-difficulty", [self.GetWidget("radio-difficulty-2"), self.GetWidget("radio-difficulty-3"), self.GetWidget("radio-difficulty-4")] )
        t.RegisterListener( self )
        self.AddWidget( t )
        t = RadioButtonGroup( "radiogroup-sound",      [self.GetWidget("radio-soundon"), self.GetWidget("radio-soundoff")] )
        t.RegisterListener( self )
        self.AddWidget( t )

        t = BoardDisplay( "board-display", (0,0,600,600), (69,143), (66,66), "Board", "StoneRed", "StoneBlue", "Stone lands", self.attachedGame )
        t.RegisterListener( self )
        self.AddWidget( t )

        self.AddWidget( TextImage( "status-text", (0,553,600,32), "Font32", " ", gcColorGrey ).AlignCenter().AlignMiddle())

        # Activate default settings
        self.GetWidget("radio-redplayerhuman").Activate()
        self.GetWidget("radio-blueplayercomputer").Activate()
        self.GetWidget("radio-difficulty-3").Activate()
        self.GetWidget("radio-soundon").Activate()
        
    def Notify( self, inMessage ):
        if inMessage == "board-display":            self.attachedGame.ApplyMoveUI( inMessage.content )
        if inMessage == "button-new":               self.attachedGame.ResetUI()
        if inMessage == "button-quit":              self.quitSelected = True
        if inMessage == "radio-redplayerhuman":     self.attachedGame.SetPlayerTypeUI( gcRed,  gcPlayerHuman )
        if inMessage == "radio-redplayercomputer":  self.attachedGame.SetPlayerTypeUI( gcRed,  gcPlayerComputer )
        if inMessage == "radio-blueplayerhuman":    self.attachedGame.SetPlayerTypeUI( gcBlue, gcPlayerHuman )
        if inMessage == "radio-blueplayercomputer": self.attachedGame.SetPlayerTypeUI( gcBlue, gcPlayerComputer )
        if inMessage == "radio-difficulty-1" or inMessage == "radio-difficulty-2" or inMessage == "radio-difficulty-3" or inMessage == "radio-difficulty-4":
            #!!! This is a pretty good example of why the message-as-string model merits replacing; the possibility that a message is a CompoundMessage prevents a check of (inMessage[0:16] == "radio-difficulty")
            self.attachedGame.SetAIDifficulty( int(inMessage[17]) )
        if inMessage == "radio-soundoff":
            self.playsounds = False
            for widget in self.widgets:
                widget.playsounds = False
        if inMessage == "radio-soundon":
            self.playsounds = True
            for widget in self.widgets:
                widget.playsounds = True

    def QuitSelected( self ): return self.quitSelected
    
    def UpdateStatus( self, inMessage="" ):
        """
        The public interface for Game to notify View as to when something has changed that might merit a graphical update.
        inMessage is a quick hack to allow moves to trigger sounds
        """
        winner = self.attachedGame.GetWinner()

        if winner == None:
            player = self.attachedGame.GetCurrentPlayer()
            if player == gcRed:  color = gcColorDarkRed
            else:                color = gcColorDarkBlue
            if self.attachedGame.GetPlayerType(player) == gcPlayerComputer:
                text = "The computer is thinking..."
            elif self.attachedGame.GetPlayerType(GetOtherPlayer(player)) == gcPlayerComputer:
                text = "It's your turn."
            else:
                if player == gcRed: text = "It's the red player's turn."
                else:               text = "It's the blue player's turn."
        else:
            if winner == gcRed:
                text = "The red player wins!"
                color = gcColorDarkRed
            elif winner == gcBlue:
                text = "The blue player wins!"
                color = gcColorDarkBlue
            else:
                text = "The game is a draw!"
                color = gcColorDarkGrey

        self.GetWidget("status-text").SetText( text, color ).AlignCenter().AlignMiddle()

        if inMessage == "moved" and self.playsounds:
            if winner == None:
                self.soundStone.play()
            elif winner == gcNil or (self.attachedGame.GetPlayerType(winner) == gcPlayerComputer and self.attachedGame.GetPlayerType(GetOtherPlayer(winner)) == gcPlayerHuman):
                self.soundLose.play()
            else:
                self.soundWin.play()
